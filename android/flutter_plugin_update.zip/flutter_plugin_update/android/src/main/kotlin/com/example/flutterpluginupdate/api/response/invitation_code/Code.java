package com.example.flutterpluginupdate.api.response.invitation_code;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Code {
    @SerializedName("endpointId")
    @Expose
    private String endpointId;
    @SerializedName("invitationCode")
    @Expose
    private String invitationCode;

    public String getEndpointId() {
        return endpointId;
    }

    public void setEndpointId(String endpointId) {
        this.endpointId = endpointId;
    }

    public String getInvitationCode() {
        return invitationCode;
    }

    public void setInvitationCode(String invitationCode) {
        this.invitationCode = invitationCode;
    }
}