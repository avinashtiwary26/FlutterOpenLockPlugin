/*
 *
 *  Copyright 2015 OpenKey. All Rights Reserved
 *
 *  @author OpenKey Inc.
 *
 */

package com.example.flutteropenkeysdkplugin.enums;

/**
 * Enum for lock type
 */
public enum MANUFACTURER {OKMOBILEKEY
}