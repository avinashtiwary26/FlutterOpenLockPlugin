package com.example.flutterpluginupdate.api.model;

public class KeyStatusRequest {

    public String status;


    /**
     * @param status
     */
    public KeyStatusRequest(String status) {
        this.status = status;
    }
}