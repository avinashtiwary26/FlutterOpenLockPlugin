package com.example.flutterpluginupdate

import android.app.Application
import android.util.Log
import com.example.flutterpluginupdate.interfaces.OpenKeyCallBack
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.MethodCallHandler
import io.flutter.plugin.common.MethodChannel.Result
import io.flutter.plugin.common.PluginRegistry.Registrar

class FlutterPluginUpdatePlugin(var openKeyManager: OpenKeyCallBack, var activity: Application): MethodCallHandler {
  companion object {
    @JvmStatic
    fun registerWith(registrar: Registrar) {
      val channel = MethodChannel(registrar.messenger(), "flutter_plugin_update")
      channel.setMethodCallHandler(FlutterPluginUpdatePlugin(registrar.openKeyManager,registrar.activity))
    }
  }
  override fun onMethodCall(call: MethodCall, result: Result) {
    if (call.method == "getPlatformVersion") {
      result.success("Android ${android.os.Build.VERSION.RELEASE}")

    }
    else if(call.method == "openkeysdkinit") {

      activity.let {
        OpenKeyManager.getInstance().init(it,"45144534-f181-4011-b142-5d53162a95c8")
      }

      result.success("Android ${android.os.Build.VERSION.RELEASE}")
    }
    else if(call.method == "openkeysdkauthnticate") {
      OpenKeyManager.getInstance().authenticate("47483543957347597",openKeyManager,false)
    }
    else if(call.method == "openkeysdkinitialize") {
      OpenKeyManager.getInstance().getKey(openKeyManager)
    }
    else if(call.method == "openkeysdkgetkey") {
      OpenKeyManager.getInstance().getKey(openKeyManager)
    }
    else if(call.method == "openkeysdkstartscanning") {
      OpenKeyManager.getInstance().startScanning(openKeyManager,"103")
    }
    else {
      result.notImplemented()
    }
  }

}
