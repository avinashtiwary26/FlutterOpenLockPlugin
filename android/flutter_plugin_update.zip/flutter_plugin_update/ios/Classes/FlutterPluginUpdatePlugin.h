#import <Flutter/Flutter.h>

@interface FlutterPluginUpdatePlugin : NSObject<FlutterPlugin>
@end
