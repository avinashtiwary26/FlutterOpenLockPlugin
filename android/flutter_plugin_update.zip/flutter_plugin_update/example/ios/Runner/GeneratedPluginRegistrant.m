//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <flutter_plugin_update/FlutterPluginUpdatePlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterPluginUpdatePlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterPluginUpdatePlugin"]];
}

@end
